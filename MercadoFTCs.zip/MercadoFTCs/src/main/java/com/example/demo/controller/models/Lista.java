package com.example.demo.controller.models;

public class Lista {

}
