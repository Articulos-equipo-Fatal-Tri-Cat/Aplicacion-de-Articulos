package com.example.demo.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.example.demo.controller.models.Lista;


@Controller
public class indexController {

	@GetMapping ({"/indexl", "/,", ""})
	public String index(Model model) {
		model.addAttribute("titulo", "Bienvenidos al MERCADO FTC´s");
		
		return "indexl";
	}
	
	@ModelAttribute ("listas")
	public List<Lista> poblarLista() {				
		List<Lista> listas = Arrays.asList(
				new Lista("Gansito", "Marinela", "$15", "10", "Pastelito sabor chocolate, con relleno de fresa", "Bimbo"),
				new Lista("Takis", "Barcel", "$11", "5", "Frituras sabor chile y limón", "Barcel"),
				new Lista("Emperador clasico", "Gamesa", "$13", "15", "Galletas sabor chocolate", "Gamesa"),
				new Lista("Bubulubo", "Sonrix", "$8", "20", "Chocolate con relleno de fresa", "Sonrix"),
				new Lista("Hershis", "Nestle", "$16", "4", "Tableta de chocolate con leche", "Nestle"));		
		
		return listas;
	}
	
}