package com.bytecode.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
