package com.bytecode.core.service;

import java.util.List;

import com.bytecode.core.model.Post;

public interface PostService {

	public List<Post> validation(List<Post> posts) throws NullPointerException;	
	public void addClass(Class clazz);
	
}
